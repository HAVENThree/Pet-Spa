import { NgModule } from '@angular/core';
import { Routes, RouterModule, ChildrenOutletContexts } from '@angular/router';
import { DefaultLayoutComponent } from './layouts/default-layout/default-layout.component';
import { EmployeeComponent } from './pages/employee/employee.component';


const routes: Routes = [
  {
    path: '',
    component: DefaultLayoutComponent,
    children: [ {
      path: 'employee',
      component: EmployeeComponent
    }]
  },
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
