import { PnotifyService } from './../../services/pnotify.service';
import { ProductTypeService } from './../../services/product-type.service';
import { ProductType } from './../../models/ProductType';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { ProductService } from './../../services/product.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Product } from '../../models/Product';
import { renderFlagCheckIfStmt } from '@angular/compiler/src/render3/view/template';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  @ViewChild('productModal', { static: false }) productModal: ModalDirective;
  products: Product[] = []
  product: Product = { productType: { id: 0 } } as Product;
  productTypes: ProductType[] = []
  productType: ProductType = {} as ProductType;
  page: number = 1;
  itemsPerPage: number = 3;
  selectedFile: File = null
  imagePreview: String = "";
  constructor(private productService: ProductService, private productTypeService: ProductTypeService, private pnotify: PnotifyService) { }

  private loadingData() {
    this.productService.getList().subscribe(res => {
      this.products = res;
    });

    this.productTypeService.getList().subscribe(res => {
      this.productTypes = res
      console.log(res);
    });
  }

  ngOnInit(): void {
    this.loadingData();
  }

  showAdd() {
    this.product = { id: 0, productType: { id: 0 } } as Product
    this.productModal.show();
  }

  showEdit(e, id: number) {
    e.preventDefault();
    this.productService.get(id).subscribe(res => {
      this.product = res;
      this.productModal.show();
    });
  }
  onFileSelected(event) {
    this.selectedFile = <File>event.target.files[0];
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.onload = (event: any) => {
        this.imagePreview = event.target.result;
      }
      reader.readAsDataURL(event.target.files[0]);
    }
  }

  // uploadFile() {
   
  //   data.append('image', this.selectedFile, this.selectedFile.name);
  //   this.productService.uploadImage(data).subscribe(res => {
  //     console.log(res);
  //   });
  // }
  closeModal() {
    this.productModal.hide();
  }

  delete(e: Event, id: number) {
    e.preventDefault();
    this.pnotify.showConfirm("Confirm", "Are you sure ?", yes => {
      if (yes) {
        this.productService.delete(id).subscribe(res => {
          console.log(res);
          if (res != null) {
            this.pnotify.showSuccess('Success', 'Delete successfully !');
            this.loadingData();
          } else {
            this.pnotify.showFailure('Failed', 'Delete failed !')
          }
        });
      }
    });
  };

  save() {
    const data = new FormData();
    data.append("image", this.selectedFile)
    this.product.imageData = data;
    if (this.product.id === 0) {
      this.productService.add(this.product).subscribe(res => {
        if (Error) {
          this.pnotify.showSuccess('Success', 'Insert successfully !')
          this.closeModal();
          this.loadingData();
        } else {
          this.pnotify.showFailure('Failed', 'Insert failed !')
        }

      });
    } else {
      this.productService.update(this.product).subscribe(res => {
        if (Error) {
          this.pnotify.showSuccess('Success', 'Update successfully !')
          this.closeModal();
          this.loadingData();
        } else {
          this.pnotify.showFailure('Failed', 'Update failed !')
        }
      });
    }
  }
}