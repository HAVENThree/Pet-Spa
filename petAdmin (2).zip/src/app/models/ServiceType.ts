import { Service } from './Service';
export interface ServiceType {
    id: number;
    stypCode: string;
    name: string;
}