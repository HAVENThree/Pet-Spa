import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor() { }
  baseURL = "http://localhost:7777/"
  URL = {
    customers : this.baseURL + "customers",
    products : this.baseURL + "products"
  }
}
