import { Service } from './../models/Service';
import { HttpClient } from '@angular/common/http';
import { ApiService } from './api.service';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServicesService {

  constructor(private apiService: ApiService, private http: HttpClient) { }

  getList():Observable<[Service]> {
    return this.http.get<[Service]>(this.apiService.URL.products);
  }
}
