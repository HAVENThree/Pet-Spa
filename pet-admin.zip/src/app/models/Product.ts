export interface Product {
    PRO_ID: number;
    name: string;
    image: string;
    price: number;
}
                                                                                                                                                                                                                                                                                                                                                                                                                