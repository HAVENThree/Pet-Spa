export interface ProductType {
    PRO_TYPE_ID: number;
    name: string;
}