export interface Service {
    SER_ID: number;
    name: string;
    image: string;
    price: number;
}