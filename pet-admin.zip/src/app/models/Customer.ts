export interface Customer {
    name: string;
    phone: string;
    address: string;
}
