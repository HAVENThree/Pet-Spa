export interface ServiceType {
    SER_TYPE_ID: number;
    name: string;
}