import { CustomersService } from './../../services/customers.service';
import { Customer } from './../../models/Customer';
import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {

  Customers : Customer[] = [];
  constructor(private customersService : CustomersService) { }

  private loadingData() {
    this.customersService.getList().subscribe(res => {
      this.Customers = res;
    });
  }

  ngOnInit(): void {
    this.loadingData();
  }

}
