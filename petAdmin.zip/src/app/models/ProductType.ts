export interface ProductType {
    id : number
    ptypCode: number;
    name: string;
}