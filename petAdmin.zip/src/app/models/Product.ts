export interface Product {
    id: number;
    pro_code: number;
    name: string;
    image: string;
    price: number;
}
                                                                                                                                                                                                                                                                                                                                                                                                                