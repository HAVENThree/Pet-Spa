import { ServicesService } from './../../services/services.service';
import { Service } from './../../models/Service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})
export class ServicesComponent implements OnInit {

  services : Service[] = []
  constructor(private servicesService : ServicesService) { }

  private loadingData() {
    this.servicesService.getList().subscribe(res => {
      this.services = res;
    });
  }

  ngOnInit(): void {
    this.loadingData();
  }

}
