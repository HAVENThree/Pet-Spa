import { ModalDirective } from 'ngx-bootstrap/modal';
import { ProductService } from './../../services/product.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Product } from '../../models/Product';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  @ViewChild('productModal', { static: false }) productModal: ModalDirective;
  products: Product[] = []
  product: Product = {} as Product;
  constructor(private productService: ProductService) { }

  private loadingData() {
    this.productService.getList().subscribe(res => {
      this.products = res;
    });
  }

  showAdd() {
    this.product = { id: 0 } as Product;
    this.productModal.show();
  }

  closeModal() {
    this.productModal.hide();
  }

  ngOnInit(): void {
    this.loadingData();
  }

  delete(e: Event, id: number) {
    e.preventDefault();
    this.productService.delete(id).subscribe(res => {
      this.loadingData();
    });
  }
}
