import { ServiceTypeService } from './../../services/service-type.service';
import { ServiceType } from './../../models/ServiceType';
import { ServicesService } from './../../services/services.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-type',
  templateUrl: './service-type.component.html',
  styleUrls: ['./service-type.component.css']
})
export class ServiceTypeComponent implements OnInit {

  serviceTypes : ServiceType[] = [];
  constructor(private serviceTypeService : ServiceTypeService) { }

  private loadingData() {
    this.serviceTypeService.getList().subscribe(res => {
      this.serviceTypes = res;
    });
  }

  ngOnInit(): void {
    this.loadingData();
  }
}
