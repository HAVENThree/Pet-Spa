import { ModalDirective } from 'ngx-bootstrap/modal';
import { ProductTypeService } from './../../services/product-type.service';
import { ProductType } from './../../models/ProductType';
import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-product-types',
  templateUrl: './product-types.component.html',
  styleUrls: ['./product-types.component.css']
})
export class ProductTypesComponent implements OnInit {

  @ViewChild('productTypeModal', { static: false }) productTypeModal: ModalDirective;
  productType = {} as ProductType;
  productTypes: ProductType[] = []
  constructor(private productTypeService: ProductTypeService) { }

  private loadingData() {
    this.productTypeService.getList().subscribe(res => {
      this.productTypes = res;
    });
  }

  showAdd() {
    this.productType = { id: 0 } as ProductType
    this.productTypeModal.show();
  }

  showEdit(e , id: number) {
    e.preventDefault();
    this.productTypeService.get(id).subscribe(res => {
      this.productType = res;
      this.productTypeModal.show();
    });
  }

  closeModal() {
    this.productTypeModal.hide();
  }

  ngOnInit(): void {
    this.loadingData();
  }


  delete(e: Event, id: number) {
    e.preventDefault();
    this.productTypeService.delete(id).subscribe(res => {
      this.loadingData();
    });
  }
  save() {
    if (this.productType.id === 0) {
      this.productTypeService.add(this.productType).subscribe(res => {
        this.closeModal();
        this.loadingData();
      });
    } else {
      this.productTypeService.update(this.productType).subscribe(res => {
        this.closeModal();
        this.loadingData();
      }
      );
    }
  }
}
