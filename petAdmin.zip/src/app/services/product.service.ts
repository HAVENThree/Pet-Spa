
import { ApiService } from './api.service';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from '../models/Product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private apiService: ApiService, private http: HttpClient) {}

  getList():Observable<[Product]> {
    return this.http.get<[Product]>(this.apiService.URL.products);
  }
  delete(id: number): Observable<Product>  {
    return this.http.delete<Product>(`${this.apiService.URL.products}/${id}`);
  }
}
