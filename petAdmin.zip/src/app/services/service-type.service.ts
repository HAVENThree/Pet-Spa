import { Observable } from 'rxjs';
import { ServiceType } from './../models/ServiceType';
import { HttpClient } from '@angular/common/http';
import { ApiService } from './api.service';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServiceTypeService {

  constructor(private apiService: ApiService, private http: HttpClient) { }

  getList():Observable<[ServiceType]> {
    return this.http.get<[ServiceType]>(this.apiService.URL.serviceTypes);
  }
}
