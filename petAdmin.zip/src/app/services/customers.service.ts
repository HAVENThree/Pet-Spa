import { ApiService } from './api.service';
import { Customer } from './../models/Customer';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CustomersService {

  constructor(private apiService: ApiService, private http: HttpClient) {}

  getList():Observable<[Customer]> {
    return this.http.get<[Customer]>(this.apiService.URL.customers);
  }
  delete(id: number): Observable<Customer>  {
    return this.http.delete<Customer>(`${this.apiService.URL.products}/${id}`);
  }
}
